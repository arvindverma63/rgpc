<head>
		<!-- Mobile Specific Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!-- Favicon-->
		<!-- Author Meta -->
		<meta name="author" content="colorlib">
		<!-- Meta Description -->
		<meta name="description" content="">
		<!-- Meta Keyword -->
		<meta name="keywords" content="">
		<!-- meta character set -->
		<meta charset="UTF-8">
		<!-- Site Title -->
		<title>Education</title>

		<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet">
			<!--
			CSS
			============================================= -->
            <link rel="stylesheet" href="<?php echo e(asset('css/linearicons.css')); ?>">
            <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
            <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
            <link rel="stylesheet" href="<?php echo e(asset('css/magnific-popup.css')); ?>">
            <link rel="stylesheet" href="<?php echo e(asset('css/nice-select.css')); ?>">
            <link rel="stylesheet" href="<?php echo e(asset('css/animate.min.css')); ?>">
            <link rel="stylesheet" href="<?php echo e(asset('css/owl.carousel.css')); ?>">
            <link rel="stylesheet" href="<?php echo e(asset('css/jquery-ui.css')); ?>">
            <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
		</head>
<?php /**PATH C:\Users\Hp\Documents\secret\rgpc\resources\views/components/head.blade.php ENDPATH**/ ?>